package com.example.mynumbergameapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.GridView
import java.util.*
import kotlin.collections.HashMap
import android.view.Gravity
import android.widget.RelativeLayout
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.constraintlayout.widget.ConstraintLayout


class GameArea : AppCompatActivity() {
    var boardElementMap: HashMap<String, Int>? = HashMap()
    var previousBoardElementMap: HashMap<String, Int>? = null
    var grid: GridView? = null
    var goal: Int = 0
    var type: String = ""

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_area)
        goal = intent.extras?.getInt(MainActivity.WIN_GOAL) ?: 2048
        type = intent.extras?.getString(MainActivity.BOARD_SIZE) ?: "4 x 4"
        findViewById<TextView>(R.id.txtBoardType).text = type
        findViewById<TextView>(R.id.txtWinGoal).text = goal.toString()

        grid = findViewById(R.id.gameView)
        val r1 = Random().nextInt(16) + 1
        var r2 = Random().nextInt(16) + 1

        if (r1 == r2 && r2 != 16) {
            r2++
        } else {
            if (r1 == r2) {
                r2--
            }
        }
        // Initializing a new String Array
        val gridNums = if (type == "4 x 4") {
            grid!!.numColumns = 4
            CONSTANT.grids4x4
        } else {
            grid!!.numColumns = 8
            CONSTANT.grids8x8
        }

        val choice = intArrayOf(2, 4)
        val ind1 = Random().nextInt(choice.size)
        val ind2 = Random().nextInt(choice.size)
        for (i in gridNums.indices) {
            if (gridNums[i].toInt() == r1) {
                boardElementMap!![gridNums[i]] = choice[ind1]
            }
            if (gridNums[i].toInt() == r2) {
                boardElementMap!![gridNums[i]] = choice[ind2]
            }
            if (gridNums[i].toInt() != r2 && gridNums[i].toInt() != r1) {
                boardElementMap!![gridNums[i]] = 0
            }
        }
        val plantsList: Array<String> = gridNums
        gridsUpdate(plantsList)


        grid!!.setOnTouchListener(object : OnSwipeTouchListener(this@GameArea) {
            override fun onSwipeTop() {
                previousBoardElementMap = boardElementMap
                while (!(verifyAllOkTop(1) && verifyAllOkTop(2) && verifyAllOkTop(3) && verifyAllOkTop(
                        4
                    ))
                ) {
                    for (i in 16 downTo 5) {
                        if (i > 4 && boardElementMap!![i.toString() + ""] === boardElementMap!![(i - 4).toString() + ""]) {
                            boardElementMap!![(i - 4).toString() + ""] =
                                boardElementMap!![i.toString() + ""]!! + boardElementMap!![(i - 4).toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        } else if (i > 4 && boardElementMap!![(i - 4).toString() + ""] == 0) {
                            boardElementMap!![(i - 4).toString() + ""] = boardElementMap!![i.toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        }
                    }
                }
                gridsUpdate(plantsList)
                generateNewNum()
                checkForResult()
            }

            override fun onSwipeRight() {
                previousBoardElementMap = boardElementMap
                var k = 0
                var l = 0
                while (l == 0 || !(verifyAllOkRight(4) && verifyAllOkRight(8) && verifyAllOkRight(12) && verifyAllOkRight(
                        16
                    ))
                ) {
                    l = 1
                    for (i in 1..16) {
                        if (k == 0 && boardElementMap!![i.toString() + ""] === boardElementMap!![(i + 1).toString() + ""]) {
                            boardElementMap!![(i + 1).toString() + ""] =
                                boardElementMap!![i.toString() + ""]!! + boardElementMap!![(i + 1).toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        } else if (k == 0 && boardElementMap!![(i + 1).toString() + ""] == 0) {
                            boardElementMap!![(i + 1).toString() + ""] = boardElementMap!![i.toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        }
                        k = if (i / 4 != (i + 1) / 4) {
                            1
                        } else {
                            0
                        }
                    }
                }
                gridsUpdate(plantsList)
                generateNewNum()
                checkForResult()
            }

            override fun onSwipeLeft() {
                previousBoardElementMap = boardElementMap
                var k: Int
                var l = 0
                while (l == 0 || !(verifyAllOkLeft(1) && verifyAllOkLeft(5) && verifyAllOkLeft(9) && verifyAllOkLeft(
                        13
                    ))
                ) {
                    l = 1
                    for (i in 16 downTo 2) {
                        k = if (i == 13 || i == 9 || i == 5) {
                            1
                        } else {
                            0
                        }
                        if (k == 0 && boardElementMap!![i.toString() + ""] === boardElementMap!![(i - 1).toString() + ""]) {
                            boardElementMap!![(i - 1).toString() + ""] =
                                boardElementMap!![i.toString() + ""]!! + boardElementMap!![(i - 1).toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        } else if (k == 0 && boardElementMap!![(i - 1).toString() + ""] == 0) {
                            boardElementMap!![(i - 1).toString() + ""] = boardElementMap!![i.toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        }
                    }
                }
                gridsUpdate(plantsList)
                generateNewNum()
                checkForResult()
            }

            override fun onSwipeBottom() {
                previousBoardElementMap = boardElementMap
                var k = 0
                while (k == 0 || !(verifyAllOkBottom(13) && verifyAllOkBottom(14) && verifyAllOkBottom(
                        15
                    ) && verifyAllOkBottom(
                        16
                    ))
                ) {
                    k = 1
                    for (i in 1..12) {
                        if (i < 13 && boardElementMap!![i.toString() + ""] === boardElementMap!![(i + 4).toString() + ""]) {
                            boardElementMap!![(i + 4).toString() + ""] =
                                boardElementMap!![i.toString() + ""]!! + boardElementMap!![(i + 4).toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        } else if (i < 13 && boardElementMap!![(i + 4).toString() + ""] == 0) {
                            boardElementMap!![(i + 4).toString() + ""] = boardElementMap!![i.toString() + ""]!!
                            boardElementMap!![i.toString() + ""] = 0
                        }
                    }
                }
                gridsUpdate(plantsList)
                generateNewNum()
                checkForResult()
            }
        })
    }

    fun verifyAllOkTop(loc: Int): Boolean {
        if (boardElementMap!![loc.toString() + ""] == 0 && boardElementMap!![(loc + 4).toString() + ""] == 0 && boardElementMap!!["" + (loc + 8)] == 0 && boardElementMap!!["" + (loc + 12)] == 0) {
            return true
        } else if (boardElementMap!![(loc + 4).toString() + ""] == 0 && boardElementMap!!["" + (loc + 8)] == 0 && boardElementMap!!["" + (loc + 12)] == 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc + 8)] == 0 && boardElementMap!!["" + (loc + 12)] == 0 && boardElementMap!!["" + (loc + 4)] != 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc + 12)] == 0 && boardElementMap!!["" + (loc + 4)] != 0 && boardElementMap!!["" + loc] != 0 && boardElementMap!!["" + (loc + 8)] != 0) {
            return true
        } else if (boardElementMap!![loc.toString() + ""] != 0 && boardElementMap!![(loc + 4).toString() + ""] != 0 && boardElementMap!!["" + (loc + 8)] != 0 && boardElementMap!!["" + (loc + 12)] != 0) {
            return true
        }
        return false
    }

    fun verifyAllOkBottom(loc: Int): Boolean {
        if (boardElementMap!![loc.toString() + ""] == 0 && boardElementMap!![(loc - 4).toString() + ""] == 0 && boardElementMap!!["" + (loc - 8)] == 0 && boardElementMap!!["" + (loc - 12)] == 0) {
            return true
        } else if (boardElementMap!![(loc - 4).toString() + ""] == 0 && boardElementMap!!["" + (loc - 8)] == 0 && boardElementMap!!["" + (loc - 12)] == 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc - 8)] == 0 && boardElementMap!!["" + (loc - 12)] == 0 && boardElementMap!!["" + (loc - 4)] != 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc - 12)] == 0 && boardElementMap!!["" + (loc - 4)] != 0 && boardElementMap!!["" + loc] != 0 && boardElementMap!!["" + (loc - 8)] != 0) {
            return true
        } else if (boardElementMap!![loc.toString() + ""] != 0 && boardElementMap!![(loc - 4).toString() + ""] != 0 && boardElementMap!!["" + (loc - 8)] != 0 && boardElementMap!!["" + (loc - 12)] != 0) {
            return true
        }
        return false
    }

    fun verifyAllOkRight(loc: Int): Boolean {
        if (boardElementMap!![loc.toString() + ""] == 0 && boardElementMap!![(loc - 1).toString() + ""] == 0 && boardElementMap!!["" + (loc - 2)] == 0 && boardElementMap!!["" + (loc - 3)] == 0) {
            return true
        } else if (boardElementMap!![(loc - 1).toString() + ""] == 0 && boardElementMap!!["" + (loc - 2)] == 0 && boardElementMap!!["" + (loc - 3)] == 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc - 2)] == 0 && boardElementMap!!["" + (loc - 3)] == 0 && boardElementMap!!["" + (loc - 1)] != 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc - 3)] == 0 && boardElementMap!!["" + (loc - 1)] != 0 && boardElementMap!!["" + loc] != 0 && boardElementMap!!["" + (loc - 2)] != 0) {
            return true
        } else if (boardElementMap!![loc.toString() + ""] != 0 && boardElementMap!![(loc - 1).toString() + ""] != 0 && boardElementMap!!["" + (loc - 2)] != 0 && boardElementMap!!["" + (loc - 3)] != 0) {
            return true
        }
        return false
    }

    fun verifyAllOkLeft(loc: Int): Boolean {
        if (boardElementMap!![loc.toString() + ""] == 0 && boardElementMap!![(loc + 1).toString() + ""] == 0 && boardElementMap!!["" + (loc + 2)] == 0 && boardElementMap!!["" + (loc + 3)] == 0) {
            return true
        } else if (boardElementMap!![(loc + 1).toString() + ""] == 0 && boardElementMap!!["" + (loc + 2)] == 0 && boardElementMap!!["" + (loc + 3)] == 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc + 2)] == 0 && boardElementMap!!["" + (loc + 3)] == 0 && boardElementMap!!["" + (loc + 1)] != 0 && boardElementMap!!["" + loc] != 0) {
            return true
        } else if (boardElementMap!!["" + (loc + 3)] == 0 && boardElementMap!!["" + (loc + 1)] != 0 && boardElementMap!!["" + loc] != 0 && boardElementMap!!["" + (loc + 2)] != 0) {
            return true
        } else if (boardElementMap!![loc.toString() + ""] != 0 && boardElementMap!![(loc + 1).toString() + ""] != 0 && boardElementMap!!["" + (loc + 2)] != 0 && boardElementMap!!["" + (loc + 3)] != 0) {
            return true
        }
        return false
    }

    fun checkForResult() {
        val cl = findViewById<View>(R.id.wholelayout) as ConstraintLayout
        val lll = LinearLayout(this)
        lll.layoutParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        lll.setBackgroundColor(resources.getColor(R.color.bg_color))
        lll.gravity = Gravity.CENTER
        val resultTextView = TextView(this)
        for (key in boardElementMap!!.keys) {
            if (boardElementMap!![key] == goal) {
                resultTextView.text = CONSTANT.WIN
                resultTextView.gravity = Gravity.CENTER
                lll.addView(resultTextView)
                cl.addView(lll)
                return
            }
        }
        for (key in boardElementMap!!.keys) {
            if (boardElementMap!![key] !== previousBoardElementMap!![key]) {
                return
            }
        }
        resultTextView.text = CONSTANT.GAME_OVER
        resultTextView.gravity = Gravity.CENTER
        lll.addView(resultTextView)
        cl.addView(lll)
    }

    fun generateNewNum() {
        val ran = Random()
        var i = ran.nextInt(16) + 1
        var flag = 0
        for (key in boardElementMap!!.keys) {
            if (boardElementMap!![key] != 0) {
                flag++
            }
        }
        if (flag != 16) {
            while (boardElementMap!![i.toString() + ""] != 0) {
                i = ran.nextInt(16) + 1
            }
            val choice = intArrayOf(2, 4)
            val ind1 = ran.nextInt(choice.size)
            boardElementMap!![i.toString() + ""] = choice[ind1]

            val plantsList = if (type == "4 x 4") {
                CONSTANT.grids4x4
            } else {
                CONSTANT.grids8x8
            }
            gridsUpdate(plantsList)
        }
    }

    fun gridsUpdate(plantsList: Array<String>) {
        val l: Array<String> = plantsList
        grid!!.adapter = object : ArrayAdapter<String?>(
            this, android.R.layout.simple_list_item_1, l
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)

                val tv = view as TextView

                val lp = RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.MATCH_PARENT
                )
                tv.layoutParams = lp
                tv.gravity = Gravity.CENTER
                if (type == "4 x 4") {
                    tv.width = 100
                    tv.height = 210
                    tv.textSize = 20f
                } else {
                    tv.textSize = 10f
                }

                if (boardElementMap!![l[position]] != 0) {
                    Log.i("TAG", position.toString() + "")
                    Log.i("TAG", l[position])
                    tv.text = boardElementMap!![l[position]].toString()
                } else {
                    tv.text = ""
                }
                tv.id = position
                tv.setBackgroundColor(resources.getColor(R.color.grid_color))
                return tv
            }
        }
    }
}