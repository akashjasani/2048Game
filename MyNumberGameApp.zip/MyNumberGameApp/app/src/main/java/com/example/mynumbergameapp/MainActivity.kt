package com.example.mynumbergameapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.RadioButton


class MainActivity : AppCompatActivity() {
    private var type = "4 x 4"
    private var winningGoal = 2048

    companion object{
        const val WIN_GOAL = "WIN_GOAL"
        const val BOARD_SIZE = "BOARD_SIZE"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun startGame(v: View?) {
        val i = Intent(this, GameArea::class.java)
        i.putExtra(WIN_GOAL, winningGoal)
        i.putExtra(BOARD_SIZE, type)
        startActivity(i)
    }

    fun onRadioButtonClicked(view: View) {
        if (view is RadioButton) {
            // Is the button now checked?
            val checked = view.isChecked

            // Check which radio button was clicked
            when (view.getId()) {
                R.id.radio_eight ->
                    if (checked) {
                        type = "8 x 8"
                    }
                R.id.radio_four ->
                    if (checked) {
                        type = "4 x 4"
                    }
                R.id.radio_2048 ->
                    if (checked) {
                        winningGoal = 2048
                    }
                R.id.radio_4096 ->
                    if (checked) {
                        this.winningGoal = 4096
                    }
            }
        }
    }
}